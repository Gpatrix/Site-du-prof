#include <Arduino.h>
#include "multiBlink.h"

/* make the builtin LED blink with the specified half period and duration - using delay()
 */
void busyBlink(uint8_t ledPin, uint16_t halfPeriod, uint32_t duration) {
  uint32_t millisecondsCounter = 0;
  while (millisecondsCounter <= duration - halfPeriod) {
    digitalWrite(ledPin, HIGH);
    delay(halfPeriod);
    millisecondsCounter += halfPeriod;
    digitalWrite(ledPin, LOW);
    if (millisecondsCounter > duration - halfPeriod) {
      return;
    } // else
    delay(halfPeriod);
    millisecondsCounter += halfPeriod;
  }
}

/* make the builtin LED blink with the specified pulse and period - without delay()
 */
void iddleBlink(uint8_t ledPin, uint32_t pulse, uint32_t period, bool synchro) {
  const uint32_t rest = period - pulse;
  static uint32_t previousBlinkMillis = millis();
  if (synchro) {
    digitalWrite(ledPin, HIGH);      // during synchronization, LED is steady
    previousBlinkMillis = millis();
  }
  else if (digitalRead(ledPin) == HIGH) {
    if ((millis() - previousBlinkMillis) >= pulse) {
      previousBlinkMillis += pulse;
      digitalWrite(ledPin, LOW);
    }
  }
  else { // LED is LOW
    if ((millis() - previousBlinkMillis) >= rest) {
      previousBlinkMillis += rest;
      digitalWrite(ledPin, HIGH);
    }
  }
}