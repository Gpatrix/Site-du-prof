#ifndef NTP_STUDY_H_INCLUDED
#define NTP_STUDY_H_INCLUDED

// All function prototypes
void     displayHeader(byte * ntpMessage);
uint8_t  decodeVN(byte * ntpMessage);
uint8_t  decodeMode(byte * ntpMessage);
uint8_t  decodeStratum(byte * ntpMessage);
uint32_t decodePoll(byte * ntpMessage);
float    decodePrecision(byte * ntpMessage);
uint32_t decodeReference(byte * ntpMessage);
String   decodeString(byte * ntpMessage);
void     displayAllNTPtimestamps(byte * ntpMessage);
void     displayNTPtimestamp(String name, byte * ntpMessage, uint8_t offsetInSec);

#endif

