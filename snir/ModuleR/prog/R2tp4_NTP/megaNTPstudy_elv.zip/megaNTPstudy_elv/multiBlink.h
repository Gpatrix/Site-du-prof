#ifndef MULTI_BLINK_H_INCLUDED
#define MULTI_BLINK_H_INCLUDED

// All function prototypes
void busyBlink(uint8_t ledPin, uint16_t halfPeriod, uint32_t duration);
void iddleBlink(uint8_t ledPin, uint32_t pulse, uint32_t period, bool synchro);
 
#endif


