#ifndef NTP_ETHERNET_CLIENT_H_INCLUDED
#define NTP_ETHERNET_CLIENT_H_INCLUDED

#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <TimeLib.h> // Arduino Time library
#include <Timezone.h>

#include "multiBlink.h"

#define NTP_HEADER_SIZE     XX

// All function prototypes
void     startEthernet(byte * macAddress);
void     getNTPpacket(byte * ntpMessage, String kissCode, uint32_t orgTimestamp, uint32_t & millisAtRequest, uint32_t & millisAtReceived);
bool     NTPrequest(byte * ntpMessage, String kissCode, uint32_t orgTimestamp, uint32_t & millisAtReceived);
void     sendNTPpacket(byte * ntpMessage, String kissCode, uint32_t orgTimestamp);
uint8_t  decodeLI(byte * ntpMessage);
uint32_t decodeTimestamp(byte * ntpMessage, int8_t byteOffset);
float    decodeFracTimestamp(byte * ntpMessage, int8_t byteOffset);
time_t   getUnixTimestamp(byte * ntpMessage, uint32_t deltamillis);
int      resynchroTime(byte * ntpMessage, uint32_t & millisAtRequest, uint32_t & millisAtReceived);
time_t   makeRoundTimestamp(time_t timestamp, uint32_t period);
String   dateAndTimeString(uint8_t wday, uint8_t day, uint8_t month, uint16_t year, uint8_t hour, uint8_t min, uint8_t sec, char * tz);

#endif