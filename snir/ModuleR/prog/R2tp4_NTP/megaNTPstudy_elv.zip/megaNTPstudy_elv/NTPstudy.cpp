#include <Arduino.h>
#include "NTPethernetClient.h"
#include "NTPstudy.h"

void displayHeader(byte * ntpMessage) {
  Serial.print("LI = ");
  Serial.print(decodeLI(ntpMessage));
  Serial.print("    VN = ");
  Serial.print(decodeVN(ntpMessage));
  Serial.print("    Mode = ");
  Serial.print(decodeMode(ntpMessage));
  Serial.print("    Stratum = ");
  Serial.println(decodeStratum(ntpMessage));
  Serial.print("Poll = ");
  Serial.print(decodePoll(ntpMessage));
  Serial.print("    Precision = ");
  Serial.println(decodePrecision(ntpMessage), 10); // 10 fp digits
  switch (decodeStratum(ntpMessage)) {
    case 0: 
      Serial.print("Kiss of death: ");
      Serial.println(decodeString(ntpMessage));
    break;
    case 1:
      Serial.print("Reference id: ");
      Serial.println(decodeString(ntpMessage));
    break;
    default: 
      Serial.print("Reference id: ");
      Serial.println(decodeReference(ntpMessage), HEX);
  }
}

uint8_t decodeVN(byte * ntpMessage) {
  return 0; // ?
}

uint8_t decodeMode(byte * ntpMessage) {
  return 0; // ?
}

uint8_t decodeStratum(byte * ntpMessage) {
  return 0; // ?
}

uint32_t decodePoll(byte * ntpMessage) {
  return 0; // ?
}

float decodePrecision(byte * ntpMessage) {
  return 0; // ?
}

String decodeString(byte * ntpMessage) {
  String code = "";
  // ?
  // ?
  // ?
  return code;
}

uint32_t decodeReference(byte * ntpMessage) {
  uint32_t reference = 0;
  const int8_t byteOffset = 12;
  for (int8_t byteRank = 0, bitShift = 24; byteRank <= 3; byteRank++, bitShift -= 8) {
    reference += uint32_t(ntpMessage[byteRank + byteOffset]) << bitShift;
  }
  return reference;
}

void displayAllNTPtimestamps(byte * ntpMessage) {
  Serial.println("All NTP timestamps: ");
  displayNTPtimestamp("ref", ntpMessage, XX);
  displayNTPtimestamp("org", ntpMessage, XX);
  displayNTPtimestamp("rec", ntpMessage, XX);
  displayNTPtimestamp("xmt", ntpMessage, XX);
  Serial.flush();
}

void displayNTPtimestamp(String name, byte * ntpMessage, uint8_t offsetInSec) {
  Serial.print(name + " = ");
  Serial.print(decodeTimestamp(ntpMessage, byteOffset));      // integer part
  Serial.print(" + ");
  Serial.println(decodeFracTimestamp(ntpMessage, byteOffset + 4), 6); // frac
}



