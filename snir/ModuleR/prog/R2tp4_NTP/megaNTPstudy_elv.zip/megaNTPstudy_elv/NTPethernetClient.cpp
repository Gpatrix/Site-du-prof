#include "NTPethernetClient.h"

#define UNIX_EPOCH  XXXXXXXXXX   // 70 years in seconds

#define SPI_SS_ETHERNET_PIN NN
#define LOCAL_UDP_PORT      PPPP // any value above 1023
#define SERVER_NTP_PORT     PPP

#define ONE_THOUSAND 1000  // for calculus in milliseconds

extern EthernetUDP udp;
extern uint8_t ntpPoll;          // poll interval in log2 base     
extern char ntpServerHostName[];
extern uint8_t ntpLEDpin;

byte ntpFirstWord[4] = {
  0b11100011,   // LI = 3 (unknown), Version = 4, Mode = 3 (client)
  0,            // stratum unspecified    (client)
  ntpPoll,      // cf. extern value from .ino file
  byte(-10)     // clock precision 2^-10  (about 100 µs)
};

uint32_t ntpPollInterval = round(pow(2, ntpPoll));


void startEthernet(byte * macAddress) {
  Ethernet.init(SPI_SS_ETHERNET_PIN); 
  for (uint8_t attempt = 1; attempt <= 10; attempt++) {
    if (Ethernet.begin(macAddress) == 0) {
      busyBlink(ntpLEDpin, 50, 1000); // fast blink during 1 sec
    }
    else {
      busyBlink(ntpLEDpin, 200, 1000); // normal blink
      break;
    }
  }  
}

void getNTPpacket(byte * ntpMessage, String kissCode, uint32_t orgTimestamp, uint32_t & millisAtRequest, uint32_t & millisAtReceived) {  
  udp.begin(LOCAL_UDP_PORT);
  for (int8_t attempt = 1; attempt <= 10; attempt++) {
    Serial.print("Attempt " + String(attempt) + ": ");
    millisAtRequest = millis();
    if (NTPrequest(ntpMessage, kissCode, orgTimestamp, millisAtReceived)) {
      Serial.println("connection to NTP server successful :)" );
      digitalWrite(ntpLEDpin, LOW);
      break;
    }
    else {
      Serial.println("connection to NTP server failed :(" );
      digitalWrite(ntpLEDpin, HIGH);
    }
  }  
  udp.stop();
}

bool NTPrequest(byte * ntpMessage, String kissCode, uint32_t orgTimestamp, uint32_t & millisAtReceived) {
  sendNTPpacket(ntpMessage, kissCode, orgTimestamp);     
  for (int8_t attempt = 1; attempt <= 10; attempt++) {
    if (udp.parsePacket()) {
      millisAtReceived = millis(); 
      digitalWrite(ntpLEDpin, LOW);
      udp.read(ntpMessage, NTP_HEADER_SIZE);  // copy packet into buffer
      return true;
    }
    else {
      digitalWrite(ntpLEDpin, HIGH);
    }
  }
  return false;  
}

void sendNTPpacket(byte * ntpMessage, String kissCode, uint32_t orgTimestamp) { 
  memset(ntpMessage, 0, NTP_HEADER_SIZE); // set all bytes in the buffer to 0
  for (int8_t byteRank = 0; byteRank <= 3; byteRank++) {
    ntpMessage[byteRank] = ntpFirstWord[byteRank];
  }
  for (int8_t byteRank = 12; byteRank <= 15; byteRank++) {
    if (kissCode[byteRank] == '\0') break;
    ntpMessage[byteRank] = kissCode[byteRank];
  }
  for (int8_t byteRank = 24, bitShift = 24; byteRank <= 27; byteRank++, bitShift -= 8) {
    ntpMessage[byteRank] = (orgTimestamp >> bitShift) & 0x000000FF;
  }
  // Send a packet requesting a timestamp:
  udp.beginPacket(ntpServerHostName, SERVER_NTP_PORT); 
  udp.write(ntpMessage, NTP_HEADER_SIZE);
  udp.endPacket();
}

uint8_t decodeLI(byte * ntpMessage) {
  return ntpMessage[0] >> 6;
}

uint32_t decodeTimestamp(byte * ntpMessage, int8_t byteOffset) {
  uint32_t ntpTimestamp = 0;
  for (int8_t byteRank = 0, bitShift = 24; byteRank <= 3; byteRank++, bitShift -= 8) {
    ntpTimestamp |= (uint32_t(ntpMessage[byteOffset + byteRank])) << bitShift;
  }
  return ntpTimestamp;
}

float decodeFracTimestamp(byte * ntpMessage, int8_t byteOffset) {
  uint32_t ntpFracTimestamp = 0;
  for (int8_t byteRank = 0, bitShift = 24; byteRank <= 3; byteRank++, bitShift -= 8) {
    ntpFracTimestamp |= (uint32_t(ntpMessage[byteOffset + byteRank])) << bitShift;
  }
  float frac = 0.0;
  for (int8_t bitRank = 31; bitRank >= 0; bitRank--) {
    frac += ((ntpFracTimestamp >> bitRank) & 0b1) * pow(2, bitRank - 32);
  }
  return frac;  
}

time_t getUnixTimestamp(byte * ntpMessage, uint32_t deltaMillis) {
  uint32_t xmtTimestamp = decodeTimestamp(ntpMessage, 40);
  float    xmtFrac      = decodeFracTimestamp(ntpMessage, 44);
  uint32_t addedMillis = (deltaMillis) / 2 + xmtFrac * ONE_THOUSAND;
  Serial.println("Protocol delay: " + String(addedMillis) + " ms");
  delay(ONE_THOUSAND - addedMillis % ONE_THOUSAND);
  return xmtTimestamp + 1 + addedMillis / ONE_THOUSAND  - UNIX_EPOCH;
}

int resynchroTime(byte * ntpMessage, uint32_t & millisAtRequest, uint32_t & millisAtReceived) {
  time_t utc = now();
  static time_t nextSynchroTimestamp = utc + ntpPollInterval;
  if (utc >= nextSynchroTimestamp) {
    nextSynchroTimestamp  = utc + ntpPollInterval;
    uint32_t orgTimestamp = utc + UNIX_EPOCH;
    getNTPpacket(ntpMessage, "MCST", orgTimestamp, millisAtRequest, millisAtReceived);
    if (decodeLI(ntpMessage) == 3) { 
      Serial.println("Resynchronization failed (Server not synchronized).");
      return -1;
    }
    utc = getUnixTimestamp(ntpMessage, millisAtReceived - millisAtRequest);
    setTime(utc);
    Serial.println("Unix Timestamp now: " + String(utc));
    return 1;
  }
  return 0; // not the moment
}

time_t makeRoundTimestamp(time_t timestamp, uint32_t period) {
  return timestamp - (timestamp % period) + period;
}

String dateAndTimeString(uint8_t wday, uint8_t day, uint8_t month, uint16_t year, 
                         uint8_t hour, uint8_t min, uint8_t sec, char * tz) {
  char * engDay[8] = {"undef", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
  char dateAndTime[30] = "";
  sprintf(dateAndTime, "%s %02d/%02d/%d, %02d:%02d:%02d %s", 
          engDay[wday], day, month, year, hour, min, sec, tz);
  return String(dateAndTime); 
}

