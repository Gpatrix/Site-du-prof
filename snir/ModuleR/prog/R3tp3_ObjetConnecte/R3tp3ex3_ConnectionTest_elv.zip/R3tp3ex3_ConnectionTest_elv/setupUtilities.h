#ifndef SETUP_UTILITIES_H
#define SETUP_UTILITIES_H

#define SERIAL_DEBUG  // comment to disable serial monitoring
#define STATIC_IP     // comment to use DHCP

const int8_t RED_LED_PIN  = D7;  // external led
const int8_t WIFI_LED_PIN = D0;  // nodeMCU board builtin led

#ifdef STATIC_IP
IPAddress      ip(xxx, xxx, xxx, xxx);  // to be set
IPAddress gateway(xxx, xxx, xxx, xxx);  // to be set
IPAddress  subnet(xxx, xxx, xxx, xxx);  // to be set
IPAddress    dns1(xxx, xxx, xxx, xxx);  // to be set
IPAddress    dns2(xxx, xxx, xxx, xxx);  // to be set
#endif

/* All function prototypes */
#ifdef SERIAL_DEBUG
void serialSetup();
#endif
void gpioSetup();
void wifiSetup();
#ifdef SERIAL_DEBUG
void onConnected(const WiFiEventStationModeConnected & event);
void onDisconnected(const WiFiEventStationModeDisconnected & event);
void onGotIP(const WiFiEventStationModeGotIP & event);
#endif

#endif // SETUP_UTILITIES_H