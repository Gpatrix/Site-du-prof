// Wi-Fi connection id.
const char * WIFI_SSID = "**********"; // to be set
const char * WIFI_PSWD = "**********"; // to be set