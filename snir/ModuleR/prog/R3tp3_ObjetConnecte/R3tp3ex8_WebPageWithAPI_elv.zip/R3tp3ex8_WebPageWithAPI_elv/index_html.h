const char index_html[] PROGMEM = R"=====(
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title> LED </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimal-ui"> 
    <link rel="stylesheet" href="/milligram.min.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="column"> <h3> LED state: </h3> </div>
        <div class="column"> <h3 id="ledState" style="color: red">*RED_LED_STATE*</h3> </div>
      </div>
      <div class="row">
        <div class="column">
          <button class="button" onclick="serverCall('/led_on', mergeResponse)">ON</button>
        </div>
        <div class="column">
          <button class="button button-outline" onclick="serverCall('/led_off', mergeResponse)">OFF</button>
        </div>
      </div>
    </div><!-- container -->


    <script>
      function serverCall(url, cpp_function) {
        var xml_http = new XMLHttpRequest();
        xml_http.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            cpp_function(this);  //callback
          }
        };
        xml_http.open("GET", url, true);
        xml_http.send();
      }
      function mergeResponse(xhttp) {
        document.getElementById("ledState").innerHTML = xhttp.responseText == "1" ? "ON" : "OFF";
      }
    </script>
  </body>
</html>
)=====";