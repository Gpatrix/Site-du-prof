const char index_html[] PROGMEM = R"=====(
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title> LED </title>
  </head>
  <body>
    <h1> LED state: <span id="ledState" style="color: red">*RED_LED_STATE*</span></h1>

    <h1 style="display: inline;"> LED control: 
      <button style="font-size: 100%;" onclick="serverCall('/led_on', mergeResponse)">ON</button>
      <button style="font-size: 100%;" onclick="serverCall('/led_off', mergeResponse)">OFF</button>
    </h1>
    
    <!-- AJAX callback functions -->
    <script>
      function serverCall(url, cpp_function) {
        var xml_http = new XMLHttpRequest();
        xml_http.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            cpp_function(this);  // callback
          }
        };
        xml_http.open("GET", url, true);
        xml_http.send();
      }
      function mergeResponse(xml_http) {
        document.getElementById("ledState").innerHTML = xml_http.responseText;
      }
    </script>
  </body>
</html>
)=====";