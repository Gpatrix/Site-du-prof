const char index_html[] PROGMEM = R"=====(
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title> LED </title>
  </head>
  <body>
    <h1> LED state: <span style="color: red">*RED_LED_STATE*</span> </h1>

    <h1 style="display: inline;"> LED control: 
      <a href="/led_on"><button style="font-size: 100%;">ON</button></a>
      <a href="/led_off"><button style="font-size: 100%;">OFF</button></a>
    </h1>
  </body>
</html>
)=====";