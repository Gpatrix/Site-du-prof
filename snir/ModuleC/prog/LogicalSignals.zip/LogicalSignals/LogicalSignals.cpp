#include "LogicalSignals.h"

void updateSignal(LogicalSignal & signal) {
  signal.levels <<= 1;        // record previous level on bit rank 1
  // copy current level on bit rank 0 and clear all bits ranging over rank 1
  signal.levels = ((digitalRead(signal.pin) | signal.levels) & 0b11);
}

bool isLow (LogicalSignal signal) {
  return ((signal.levels & 0b01) == 0);
}

bool isHigh (LogicalSignal signal) {
  return ((signal.levels & 0b01) == 1);
}

bool risingEdge (LogicalSignal signal) {
  return (signal.levels == 0b01);
}

bool fallingEdge (LogicalSignal signal) {
  return (signal.levels == 0b10);
}

bool edge (LogicalSignal signal) {
  return (signal.levels == 0b01 || signal.levels == 0b10);
}