Arduino library module "LogicialSignals"

Designed to manage logical signals on the digital port of Arduino boards
- detect both logical levels (HIGH or LOW)
- detect all kind of edges   (rising, falling or both)

To detect something happening on a digital pin, you need to:
- declare a structured variable of type LogicialSignal, 
  (specifiing the pin number and the initial level expected on the pin)
  example: LogicalSignal button = {buttonPin, 0b00}; // LOW initial level expected

- to call the update function at each iteration of loop function
  example: updateSignal(button);

- to call a detection function whenever needed
  example: if (risingEdge(button))   // etc.  