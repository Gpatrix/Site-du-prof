#include <Arduino.h>

// Main type to be uses
struct LogicalSignal {
  uint8_t pin;  // pin number to be declared as INPUT our INPUT_PULLUP
  byte levels;  // current level on bit rank 0, previous level on bit rank 1
};

// All function prototypes
void updateSignal(LogicalSignal & signal);  // to be called once in loop function
bool isLow (LogicalSignal signal);          
bool isHigh (LogicalSignal signal);         
bool risingEdge (LogicalSignal signal);
bool fallingEdge (LogicalSignal signal);
bool edge (LogicalSignal signal);